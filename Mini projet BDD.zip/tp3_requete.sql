-- Sélection de tous les enregistrements de la table 'Client'
SELECT * FROM Client;

-- Sélection de tous les enregistrements de la table 'Employe'
SELECT * FROM Employe;

-- Sélection de tous les enregistrements de la table 'Mission'
SELECT * FROM Mission;

-- Sélection de tous les enregistrements de la table 'Affecte'
SELECT * FROM Affecte;

-- Sélection de tous les enregistrements de la table 'Contrat'
SELECT * FROM Contrat;

-- Sélection de tous les enregistrements de la table 'Livrable'
SELECT * FROM Livrable;

-- Sélection de tous les enregistrements de la table 'Departement'
SELECT * FROM Departement;



-- 1ère requête 
-- Liste tous les employés avec leur département respectif
SELECT 
    Employe.ID_employe, 
    Employe.Prenom, 
    Employe.Nom_employe, 
    Departement.Nom_Departement
FROM 
    Employe
JOIN 
    Departement ON Employe.ID_Departement = Departement.ID_Departement;

-- 2ème requête 
-- Compte le nombre total d'employés dans chaque département
SELECT 
    Departement.Nom_Departement, 
    COUNT(Employe.ID_employe) AS Total_Employees
FROM 
    Employe
JOIN 
    Departement ON Employe.ID_Departement = Departement.ID_Departement
GROUP BY 
    Departement.Nom_Departement;

-- 3ème requête
-- Récupère toutes les missions assignées à chaque employé
SELECT 
    Employe.Prenom, 
    Employe.Nom_employe, 
    Mission.Nom_mission
FROM 
    Employe
JOIN 
    Affecte ON Employe.ID_employe = Affecte.ID_employe
JOIN 
    Mission ON Affecte.ID_Mission = Mission.ID_Mission;

-- 4ème requête 
-- Calcule la dépense totale en salaires par département
SELECT 
    Departement.Nom_Departement, 
    SUM(Employe.Salaire) AS Total_Salary
FROM 
    Employe
JOIN 
    Departement ON Employe.ID_Departement = Departement.ID_Departement
GROUP BY 
    Departement.Nom_Departement;

-- 5ème requête  
-- Liste tous les clients avec leurs contrats correspondants
SELECT 
    Client.Nom_Client, 
    Contrat.Description_intervention, 
    Contrat.Tarif
FROM 
    Client
JOIN 
    Contrat ON Client.ID_client = Contrat.ID_client;

-- 6ème requête  
-- Trouve les employés qui n'ont pas de supérieur hiérarchique
SELECT 
    ID_employe, 
    Prenom, 
    Nom_employe
FROM 
    Employe
WHERE 
    ID_superieur IS NULL;

-- 7ème requête  
-- Liste tous les livrables associés à chaque mission
SELECT 
    Mission.Nom_mission, 
    Livrable.Nom_Livrable, 
    Livrable.Description_livrable
FROM 
    Mission
JOIN 
    Livrable ON Mission.ID_Mission = Livrable.ID_Mission;

-- 8ème requête
-- Identifie les employés qui ont travaillé sur plus d'une mission
SELECT 
    Employe.ID_employe, 
    Employe.Prenom, 
    Employe.Nom_employe, 
    COUNT(Affecte.ID_Mission) AS Mission_Count
FROM 
    Employe
JOIN 
    Affecte ON Employe.ID_employe = Affecte.ID_employe
GROUP BY 
    Employe.ID_employe, Employe.Prenom, Employe.Nom_employe
HAVING 
    COUNT(Affecte.ID_Mission) > 1;

-- 9ème requête 
-- Calcule le salaire moyen des employés dans chaque département
SELECT 
    Departement.Nom_Departement,
    AVG(Employe.Salaire) AS Average_Salary
FROM
    Employe
JOIN
    Departement ON Employe.ID_Departement = Departement.ID_Departement
GROUP BY Departement.Nom_Departement;

-- 10ème requête 
-- Récupère les 5 employés les mieux payés
SELECT 
    ID_employe, 
    Prenom, 
    Nom_employe, 
    Salaire
FROM 
    Employe
ORDER BY 
    Salaire DESC
LIMIT 5;


-- 11 requete 
-- Mise à jour de la table Employe
UPDATE Employe

-- Nous mettons à jour la colonne Qualification dans la table Employe
SET Qualification = (
   
    -- Sous-requête pour récupérer la dernière qualification de l'employé à partir de la table Contrat
    SELECT Qualification_intervenant
    FROM Contrat

    -- Nous faisons correspondre les employés entre la table Contrat et la table Employe
    WHERE Contrat.ID_employe = Employe.ID_employe
   
    -- Trier par date de début des missions (la plus récente en premier) afin de récupérer la dernière qualification
    ORDER BY Contrat.Date_Debut DESC

    -- Limiter à un seul résultat pour obtenir uniquement la qualification la plus récente
    LIMIT 1
)

-- Condition pour mettre à jour un seul employé spécifique (Entrer l'ID de l'empoyé, à la place de "<numero_a_update>")
WHERE ID_employe = <numero_a_update>;


