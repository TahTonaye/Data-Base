CREATE DATABASE IF NOT EXISTS tp3;

-- Sélectionne la base de données 'tp3' pour les opérations suivantes
USE tp3;

-- Création de la table 'Departement'
CREATE TABLE Departement(
   ID_Departement INT,  -- Identifiant unique du département (clé primaire)
   Nom_Departement VARCHAR(50),        -- Nom du département
   PRIMARY KEY(ID_Departement)         -- Définition de la clé primaire sur 'ID_Departement'
);

-- Création de la table 'Mission'
CREATE TABLE Mission(
   ID_Mission INT ,      -- Identifiant unique de la mission (clé primaire)
   Nom_mission VARCHAR(50),            -- Nom de la mission
   Description VARCHAR(255),           -- Description détaillée de la mission
   Date_debut DATE,                    -- Date de début de la mission
   Date_fin DATE,                      -- Date de fin de la mission
   PRIMARY KEY(ID_Mission)             -- Définition de la clé primaire sur 'ID_Mission'
);

-- Création de la table 'Client'
CREATE TABLE Client(
   ID_client INT,       -- Identifiant unique du client (clé primaire)
   Nom_Client VARCHAR(50),             -- Nom du client
   Num_Client INT,                     -- Numéro du client
   PRIMARY KEY(ID_client)              -- Définition de la clé primaire sur 'ID_client'
);

-- Création de la table 'Employe'
CREATE TABLE Employe(
   ID_employe INT ,      
   Prenom VARCHAR(50),                 
   Nom_employe VARCHAR(50),            
   Poste_employe VARCHAR(50),          
   date_embauche DATE,                 
   Salaire DECIMAL(7,2),               
   Comission_individuelle DECIMAL(7,2),
   Qualification VARCHAR(50),          
   ID_superieur INT DEFAULT NULL,      
   ID_Departement INT NOT NULL,        
   PRIMARY KEY(ID_employe),
   FOREIGN KEY(ID_superieur) REFERENCES Employe(ID_employe)
      ON UPDATE CASCADE ON DELETE SET NULL,
   FOREIGN KEY(ID_Departement) REFERENCES Departement(ID_Departement)
      ON UPDATE CASCADE ON DELETE CASCADE
	);

-- Création de la table 'Contrat'
CREATE TABLE Contrat(
   ID_Contrat INT,                  -- Identifiant unique du contrat (clé primaire)
   Description_intervention VARCHAR(255),          -- Description de l'intervention prévue dans le contrat
   Date_Debut DATE,                                -- Date de début du contrat
   Qualification_intervenant VARCHAR(50) DEFAULT NULL,  -- Qualification requise pour l'intervenant
   Tarif DECIMAL(15,2),                            -- Tarif ou montant du contrat
   ID_employe INT NOT NULL,                        -- Identifiant de l'employé associé (clé étrangère)
   ID_client INT NOT NULL,                         -- Identifiant du client associé (clé étrangère)
   PRIMARY KEY(ID_Contrat),                        -- Définition de la clé primaire sur 'ID_Contrat'
   FOREIGN KEY(ID_employe) REFERENCES Employe(ID_employe)
      ON UPDATE CASCADE ON DELETE CASCADE,         -- Clé étrangère vers 'Employe'
   FOREIGN KEY(ID_client) REFERENCES Client(ID_client)
      ON UPDATE CASCADE ON DELETE CASCADE          -- Clé étrangère vers 'Client'
);

-- Création de la table 'Livrable'
CREATE TABLE Livrable(
   Id_livrable INT ,     -- Identifiant unique du livrable (clé primaire)
   Nom_Livrable VARCHAR(50),           -- Nom du livrable
   Description_livrable VARCHAR(255),  -- Description détaillée du livrable
   ID_Mission INT NOT NULL,            -- Identifiant de la mission associée (clé étrangère)
   ID_employe INT NOT NULL,            -- Identifiant de l'employé responsable (clé étrangère)
   PRIMARY KEY(Id_livrable),           -- Définition de la clé primaire sur 'Id_livrable'
   FOREIGN KEY(ID_Mission) REFERENCES Mission(ID_Mission)
      ON UPDATE CASCADE ON DELETE CASCADE,   -- Clé étrangère vers 'Mission'
   FOREIGN KEY(ID_employe) REFERENCES Employe(ID_employe)
      ON UPDATE CASCADE ON DELETE CASCADE    -- Clé étrangère vers 'Employe'
);

-- Création de la table 'Affecte' pour gérer l'affectation des employés aux missions
CREATE TABLE Affecte(
   ID_employe INT,                     -- Identifiant de l'employé (clé étrangère)
   ID_Mission INT,                     -- Identifiant de la mission (clé étrangère)
   PRIMARY KEY(ID_employe, ID_Mission),-- Clé primaire composite sur 'ID_employe' et 'ID_Mission'
   FOREIGN KEY(ID_employe) REFERENCES Employe(ID_employe)
      ON UPDATE CASCADE ON DELETE CASCADE,   -- Clé étrangère vers 'Employe'
   FOREIGN KEY(ID_Mission) REFERENCES Mission(ID_Mission)
      ON UPDATE CASCADE ON DELETE CASCADE    -- Clé étrangère vers 'Mission'
);


