
INSERT INTO Client (ID_client, Nom_Client, Num_Client) 
VALUES
(1, 'Entreprise Alpha', 1001),
(2, 'Entreprise Beta', 1002),
(3, 'Entreprise Gamma', 1003),
(4, 'Entreprise Delta', 1004),
(5, 'Entreprise Epsilon', 1005),
(6, 'Entreprise Zeta', 1006),
(7, 'Entreprise Eta', 1007),
(8, 'Entreprise Theta', 1008),
(9, 'Entreprise Iota', 1009),
(10, 'Entreprise Kappa', 1010),
(11, 'Entreprise Lambda', 1011),
(12, 'Entreprise Mu', 1012),
(13, 'Entreprise Nu', 1013),
(14, 'Entreprise Xi', 1014),
(15, 'Entreprise Omicron', 1015);

-- Insertion de départements dans la table 'Departement'
INSERT INTO Departement (ID_Departement, Nom_Departement) 
VALUES
(1, 'Informatique'),
(2, 'Réseaux'),
(3, 'Design'),
(4, 'Consulting'),
(5, 'Ressources humaines'),
(6, 'Comptabilité');

-- Insertion des employés sans supérieur hiérarchique
INSERT INTO Employe (ID_employe, Prenom, Nom_employe, Poste_employe, date_embauche, Salaire, Comission_individuelle, Qualification, ID_superieur, ID_Departement) 
VALUES
(1, 'Alice', 'Dupont', 'Développeur', '2020-01-15', 3500.00, 500.00, 'Informatique', NULL, 1),
(2, 'Bob', 'Martin', 'Chef de Projet', '2018-04-10', 4500.00, 700.00, 'Gestion de projet', NULL, 1),
(3, 'Géraldine', 'Boulanger', 'Consultant', '2016-05-12', 4200.00, 600.00, 'Consulting', NULL, 4),
(4, 'Hélène', 'Muller', 'RH', '2020-02-03', 3800.00, 0.00, 'Ressources humaines', NULL, 5),
(5, 'Jacques', 'Leclerc', 'Ingénieur', '2021-12-01', 4100.00, 500.00, 'Ingénierie', NULL, 3),
(6, 'Katia', 'Robert', 'Comptable', '2018-11-22', 3300.00, 0.00, 'Comptabilité', NULL, 6);

-- Insertion des employés avec supérieur
INSERT INTO Employe (ID_employe, Prenom, Nom_employe, Poste_employe, date_embauche, Salaire, Comission_individuelle, Qualification, ID_superieur, ID_Departement) 
VALUES
(7, 'Claire', 'Bernard', 'Analyste', '2019-06-25', 3700.00, 400.00, 'Analyse de données', 2, 1),
(8, 'David', 'Dubois', 'Technicien', '2021-03-15', 3000.00, 300.00, 'Réseaux', 2, 2),
(9, 'Emma', 'Lemoine', 'Designer', '2017-09-08', 3200.00, 350.00, 'Design graphique', 5, 3),
(10, 'Fabrice', 'Moreau', 'Développeur', '2022-11-20', 3400.00, 450.00, 'Informatique', 1, 1),
(11, 'Isaac', 'Girard', 'Développeur', '2019-07-14', 3600.00, 400.00, 'Informatique', 1, 1),
(12, 'Léa', 'Perrin', 'Marketing', '2020-06-30', 3500.00, 200.00, 'Marketing digital', 3, 4),
(13, 'Mathieu', 'Gauthier', 'Technicien', '2017-10-19', 3100.00, 250.00, 'Support technique', 4, 2),
(14, 'Nina', 'Roux', 'Consultant', '2016-01-15', 4000.00, 550.00, 'Consulting', 7, 4),
(15, 'Olivier', 'Garcia', 'Développeur', '2021-05-10', 3700.00, 450.00, 'Informatique', 1, 1);

-- Insertion des missions avec ID_Mission explicite
INSERT INTO Mission (ID_Mission, Nom_mission, Description, Date_debut, Date_fin) 
VALUES
(1, 'Développement Application Mobile', 'Créer une application mobile pour Android et iOS', '2021-01-01', '2021-06-30'),
(2, 'Mise en Place SIRH', 'Implémentation d\'un système d\'information RH', '2021-02-15', '2021-09-15'),
(3, 'Campagne Marketing Digital', 'Lancer une campagne marketing sur les réseaux sociaux', '2021-03-01', '2021-08-31'),
(4, 'Audit Financier', 'Audit complet des finances de l\'entreprise', '2021-04-01', '2021-09-30'),
(5, 'Développement Site Web', 'Établir un site web pour le client', '2021-05-10', '2021-10-15'),
(6, 'Optimisation Réseau', 'Améliorer l\'infrastructure réseau de l\'entreprise', '2021-06-20', '2021-12-31'),
(7, 'Analyse de Données', 'Analyser les données clients pour des insights', '2021-07-05', '2021-11-30'),
(8, 'Recrutement de Personnel', 'Processus de recrutement pour de nouveaux postes', '2021-08-01', '2021-12-01'),
(9, 'Formation Interne', 'Former le personnel sur de nouveaux logiciels', '2021-09-15', '2022-02-28'),
(10, 'Étude de Marché', 'Réaliser une étude de marché pour un nouveau produit', '2021-10-01', '2022-03-31'),
(11, 'Migration Cloud', 'Migrer les services vers le cloud', '2021-11-10', '2022-04-30'),
(12, 'Développement API', 'Développer des API pour les services internes', '2021-12-05', '2022-05-31'),
(13, 'Refonte Identité Visuelle', 'Moderniser l\'identité visuelle de l\'entreprise', '2022-01-15', '2022-06-30'),
(14, 'Audit Sécurité', 'Évaluer la sécurité informatique', '2022-02-20', '2022-07-31'),
(15, 'Optimisation SEO', 'Améliorer le référencement du site web', '2022-03-25', '2022-08-31');

-- Insertion des affectations entre employés et missions
INSERT INTO Affecte (ID_employe, ID_Mission) 
VALUES
(1, 1),   
(2, 1),   
(5, 1),   
(10, 1), 
(2, 5),   
(7, 6),   
(11, 6),  
(13, 7),  
(9, 10),  
(4, 3),   
(14, 3),  
(12, 2),  
(3, 2),   
(8, 2),   
(6, 4),   
(11, 4),  
(1, 4),  
(13, 14), 
(7, 14),  
(9, 12), 
(5, 5);  


INSERT INTO Contrat (ID_Contrat, Description_intervention, Date_Debut, Qualification_intervenant, Tarif, ID_employe, ID_client) 
VALUES
(1, 'Développement d\'une application de gestion', '2021-01-15', 'Expert', 15000.00, 1, 1),
(2, 'Implémentation d\'un SIRH', '2021-02-20', 'Intermédiaire', 20000.00, 3, 2),
(3, 'Campagne publicitaire en ligne', '2021-03-05', 'Intermédiaire', 12000.00, 4, 3),
(4, 'Audit des comptes annuels', '2021-04-15', 'Expert', 18000.00, 6, 1),
(5, 'Création d\'un site web', '2021-05-20', 'Débutant', 14000.00, 5, 4),
(6, 'Optimisation réseau interne', '2021-06-25', 'Intermédiaire', 16000.00, 7, 5),
(7, 'Analyse des données clients', '2021-07-10', 'Expert', 22000.00, 13, 6),
(8, 'Processus de recrutement', '2021-08-15', 'Débutant', 13000.00, 8, 7),
(9, 'Formation sur nouveaux logiciels', '2021-09-20', 'Expert', 11000.00, 12, 8),
(10, 'Étude de marché produit X', '2021-10-05', 'Intermédiaire', 19000.00, 9, 9),
(11, 'Migration vers le Cloud', '2021-11-15', 'Expert', 25000.00, 11, 10),
(12, 'Développement d\'API REST', '2021-12-10', 'Expert', 18000.00, 10, 11),
(13, 'Refonte de la charte graphique', '2022-01-20', 'Intermédiaire', 15000.00, 14, 12),
(14, 'Audit de sécurité informatique', '2022-02-25', 'Expert', 20000.00, 8, 13),
(15, 'Optimisation SEO du site', '2022-03-30', 'Intermédiaire', 14000.00, 2, 14);

INSERT INTO Livrable (Id_livrable, Nom_Livrable, Description_livrable, ID_Mission, ID_employe) 
VALUES
(1, 'Design de l\'interface utilisateur', 'Livrable pour le design de l\'application mobile', 1, 9),
(2, 'Rapport de l\'audit financier', 'Livrable contenant les résultats de l\'audit financier', 4, 6),
(3, 'Site web client', 'Site web complet pour le client', 5, 5),
(4, 'Optimisation des performances réseau', 'Amélioration des performances du réseau interne', 6, 11),
(5, 'Analyse des données clients', 'Livrable avec des insights sur les données des clients', 7, 13),
(6, 'Étude de marché', 'Rapport détaillé sur l\'étude de marché', 10, 9),
(7, 'Formation sur logiciels', 'Documentation et formation sur les nouveaux logiciels', 9, 12),
(8, 'Charte graphique', 'Refonte complète de la charte graphique', 13, 14),
(9, 'Audit de sécurité', 'Rapport de sécurité informatique', 14, 7),
(10, 'SEO amélioré', 'Optimisation SEO du site web', 15, 15);


